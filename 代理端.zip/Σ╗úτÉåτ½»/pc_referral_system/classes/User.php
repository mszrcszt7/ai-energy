<?php
/**
 * 用户类
 */
class User {
    private $db;

    public function __construct() {
        $this->db = new Database();
    }

    /**
     * 用户登录
     */
    public function login($username, $password) {
        $user = $this->db->fetch(
            "SELECT * FROM users WHERE username = ? AND status = 1", 
            [$username]
        );

        if ($user && password_verify($password, $user['password'])) {
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['username'] = $user['username'];
            $_SESSION['login_time'] = time();
            return true;
        }

        return false;
    }

    /**
     * 用户注册
     */
    public function register($username, $email, $password, $referrer_code = null) {
        // 检查用户名是否已存在
        $existing = $this->db->fetch(
            "SELECT id FROM users WHERE username = ? OR email = ?", 
            [$username, $email]
        );

        if ($existing) {
            return false;
        }

        // 查找推荐人
        $ref_by = 0;
        if ($referrer_code) {
            $referrer = $this->db->fetch(
                "SELECT id FROM users WHERE refCode = ?", 
                [$referrer_code]
            );
            if ($referrer) {
                $ref_by = $referrer['id'];
            }
        }

        // 生成推荐码
        $refCode = rand(10000000, 99999999);

        // 插入新用户
        $sql = "INSERT INTO users (username, email, password, refCode, ref_by, status, ev, sv, profile_complete, created_at, updated_at) 
                VALUES (?, ?, ?, ?, ?, 1, 1, 1, 1, NOW(), NOW())";
        
        $stmt = $this->db->query($sql, [
            $username, 
            $email, 
            password_hash($password, PASSWORD_DEFAULT), 
            $refCode, 
            $ref_by
        ]);

        return $stmt->rowCount() > 0;
    }

    /**
     * 获取用户信息
     */
    public function getUserById($id) {
        return $this->db->fetch("SELECT * FROM users WHERE id = ?", [$id]);
    }

    /**
     * 获取用户的推荐人数
     */
    public function getReferralCount($userId, $level = 1) {
        if ($level == 1) {
            return $this->db->fetch(
                "SELECT COUNT(*) as count FROM users WHERE ref_by = ?", 
                [$userId]
            )['count'];
        }

        // 递归获取多级推荐
        $count = 0;
        $directReferrals = $this->db->fetchAll(
            "SELECT id FROM users WHERE ref_by = ?", 
            [$userId]
        );

        foreach ($directReferrals as $referral) {
            if ($level > 1) {
                $count += $this->getReferralCount($referral['id'], $level - 1);
            } else {
                $count++;
            }
        }

        return $count;
    }

    /**
     * 获取团队规模
     */
    public function getTeamSize($userId, $level) {
        $sql = "";
        $params = [$userId];

        switch ($level) {
            case 1:
                $sql = "SELECT COUNT(*) as count FROM users WHERE ref_by = ?";
                break;
            case 2:
                $sql = "SELECT COUNT(*) as count FROM users u1 
                        JOIN users u2 ON u1.ref_by = u2.id 
                        WHERE u2.ref_by = ?";
                break;
            case 3:
                $sql = "SELECT COUNT(*) as count FROM users u1 
                        JOIN users u2 ON u1.ref_by = u2.id 
                        JOIN users u3 ON u2.ref_by = u3.id 
                        WHERE u3.ref_by = ?";
                break;
        }

        $result = $this->db->fetch($sql, $params);
        return $result ? $result['count'] : 0;
    }

    /**
     * 获取团队充值金额
     */
    public function getTeamDeposit($userId, $level) {
        $sql = "";
        $params = [$userId];

        // 显示累积充值金额：按各级被邀请用户在 transactions 表中累计充值（remark='deposit' 且 trx_type='+'）
        switch ($level) {
            case 1:
                $sql = "SELECT COALESCE(SUM(t.amount), 0) AS total
                        FROM users u
                        JOIN transactions t ON t.user_id = u.id
                        WHERE u.ref_by = ?
                          AND t.remark = 'deposit'
                          AND t.trx_type = '+'";
                break;
            case 2:
                $sql = "SELECT COALESCE(SUM(t.amount), 0) AS total
                        FROM users u1
                        JOIN users u2 ON u1.ref_by = u2.id
                        JOIN transactions t ON t.user_id = u1.id
                        WHERE u2.ref_by = ?
                          AND t.remark = 'deposit'
                          AND t.trx_type = '+'";
                break;
            case 3:
                $sql = "SELECT COALESCE(SUM(t.amount), 0) AS total
                        FROM users u1
                        JOIN users u2 ON u1.ref_by = u2.id
                        JOIN users u3 ON u2.ref_by = u3.id
                        JOIN transactions t ON t.user_id = u1.id
                        WHERE u3.ref_by = ?
                          AND t.remark = 'deposit'
                          AND t.trx_type = '+'";
                break;
        }

        $result = $this->db->fetch($sql, $params);
        return $result ? $result['total'] : 0;
    }

    /**
     * 获取推荐佣金收入
     */
    public function getReferralEarnings($userId) {
        $result = $this->db->fetch(
            "SELECT COALESCE(SUM(amount), 0) as total 
             FROM transactions 
             WHERE user_id = ? AND remark = 'referral_commission'", 
            [$userId]
        );

        return $result ? $result['total'] : 0;
    }

    /**
     * 获取推荐用户数量
     */
    public function getReferredUsersCount($userId) {
        // 按用户关系统计直接推荐人数
        $result = $this->db->fetch(
            "SELECT COUNT(*) AS count FROM users WHERE ref_by = ?",
            [$userId]
        );
        return $result ? (int)$result['count'] : 0;
    }

    /**
     * 获取提现金额
     */
    public function getWithdrawalAmount($userId) {
        $result = $this->db->fetch(
            "SELECT COALESCE(SUM(amount), 0) as total 
             FROM transactions 
             WHERE user_id = ? AND remark = 'withdraw' AND trx_type = '-'", 
            [$userId]
        );

        return $result ? $result['total'] : 0;
    }

    /**
     * 获取用户的直接推荐列表
     */
    public function getDirectReferrals($userId) {
        return $this->db->fetchAll(
            "SELECT id, username, email, deposit_wallet, interest_wallet, created_at 
             FROM users 
             WHERE ref_by = ? 
             ORDER BY created_at DESC", 
            [$userId]
        );
    }

    /**
     * 获取指定级别的推荐用户
     */
    public function getReferralsByLevel($userId, $level) {
        $sql = "";
        $params = [$userId];

        switch ($level) {
            case 1:
                $sql = "SELECT u.id, u.username, u.email, u.deposit_wallet, u.interest_wallet, u.created_at 
                        FROM users u WHERE u.ref_by = ? ORDER BY u.created_at DESC";
                break;
            case 2:
                $sql = "SELECT u1.id, u1.username, u1.email, u1.deposit_wallet, u1.interest_wallet, u1.created_at 
                        FROM users u1 
                        JOIN users u2 ON u1.ref_by = u2.id 
                        WHERE u2.ref_by = ? ORDER BY u1.created_at DESC";
                break;
            case 3:
                $sql = "SELECT u1.id, u1.username, u1.email, u1.deposit_wallet, u1.interest_wallet, u1.created_at 
                        FROM users u1 
                        JOIN users u2 ON u1.ref_by = u2.id 
                        JOIN users u3 ON u2.ref_by = u3.id 
                        WHERE u3.ref_by = ? ORDER BY u1.created_at DESC";
                break;
        }

        return $this->db->fetchAll($sql, $params);
    }

    /**
     * 用户退出登录
     */
    public function logout() {
        session_destroy();
        session_start();
    }
}