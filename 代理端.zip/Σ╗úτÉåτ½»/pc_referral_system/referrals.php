<?php
require_once 'config/config.php';

// 检查登录状态
requireLogin();

$user = new User();
$currentUser = getCurrentUser();

// 获取推荐数据
$referralEarnings = $user->getReferralEarnings($currentUser['id']);
$referredUsers = $user->getReferredUsersCount($currentUser['id']);
$withdrawalAmount = $user->getWithdrawalAmount($currentUser['id']);

// 获取各级别团队数据
$teamData = [];
for ($level = 1; $level <= 3; $level++) {
    $teamData[$level] = [
        'size' => $user->getTeamSize($currentUser['id'], $level),
        'deposit' => $user->getTeamDeposit($currentUser['id'], $level)
    ];
}

// 获取直接推荐列表
$directReferrals = $user->getDirectReferrals($currentUser['id']);
?>

<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>我的团队 - <?php echo SITE_NAME; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.7.2/font/bootstrap-icons.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/aos@2.3.4/dist/aos.css" rel="stylesheet">
    <style>
        body {
            background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        
        .navbar {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            box-shadow: 0 2px 20px rgba(0,0,0,0.1);
        }
        
        .navbar-brand {
            font-weight: 700;
            font-size: 1.5rem;
        }
        
        .main-container {
            margin-top: 2rem;
            margin-bottom: 2rem;
        }
        
        .stats-card {
            background: linear-gradient(135deg, #fcd535 0%, #f0b90b 100%);
            border-radius: 20px;
            color: white;
            box-shadow: 0 10px 30px rgba(252, 213, 53, 0.3);
            transition: transform 0.3s ease;
        }
        
        .stats-card:hover {
            transform: translateY(-5px);
        }
        
        .stats-card .card-body {
            padding: 2rem;
        }
        
        .stats-number {
            font-size: 2.5rem;
            font-weight: 700;
            margin-bottom: 0.5rem;
        }
        
        .stats-label {
            font-size: 1rem;
            opacity: 0.9;
        }
        
        .team-card {
            background: white;
            border-radius: 15px;
            box-shadow: 0 5px 25px rgba(0,0,0,0.08);
            transition: all 0.3s ease;
            border: none;
        }
        
        .team-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 15px 35px rgba(0,0,0,0.15);
        }
        
        .level-badge {
            display: inline-block;
            padding: 0.5rem 1rem;
            border-radius: 25px;
            font-weight: 600;
            font-size: 0.9rem;
            margin-bottom: 1rem;
        }
        
        .level-1 { background: linear-gradient(135deg, #ff9a9e 0%, #fecfef 100%); color: #fff; }
        .level-2 { background: linear-gradient(135deg, #a18cd1 0%, #fbc2eb 100%); color: #fff; }
        .level-3 { background: linear-gradient(135deg, #fad0c4 0%, #ffd1ff 100%); color: #fff; }
        
        .team-stats {
            display: flex;
            justify-content: space-between;
            margin: 1rem 0;
        }
        
        .team-stat-item {
            text-align: center;
            flex: 1;
        }
        
        .team-stat-number {
            font-size: 1.5rem;
            font-weight: 700;
            color: #333;
        }
        
        .team-stat-label {
            font-size: 0.9rem;
            color: #666;
        }
        
        .btn-details {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            border: none;
            color: white;
            border-radius: 10px;
            padding: 0.5rem 1.5rem;
            font-weight: 500;
            transition: all 0.3s ease;
        }
        
        .btn-details:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(102, 126, 234, 0.4);
            color: white;
        }
        
        .referral-table {
            background: white;
            border-radius: 15px;
            overflow: hidden;
            box-shadow: 0 5px 25px rgba(0,0,0,0.08);
        }
        
        .table th {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border: none;
            font-weight: 600;
        }
        
        .table td {
            border-color: #f8f9fa;
            vertical-align: middle;
        }
        
        .user-avatar {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background: linear-gradient(135deg, #fcd535 0%, #f0b90b 100%);
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: 600;
        }
        
        .amount-positive {
            color: #28a745;
            font-weight: 600;
        }
        
        .amount-zero {
            color: #6c757d;
        }
        
        .invite-section {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border-radius: 20px;
            padding: 2rem;
            margin-top: 2rem;
        }
        
        .invite-code {
            background: rgba(255,255,255,0.2);
            border: 2px solid rgba(255,255,255,0.3);
            border-radius: 10px;
            color: white;
            font-weight: 600;
        }
        
        .invite-code:focus {
            background: rgba(255,255,255,0.3);
            border-color: rgba(255,255,255,0.5);
            color: white;
            box-shadow: none;
        }
        
        .btn-copy {
            background: rgba(255,255,255,0.2);
            border: 2px solid rgba(255,255,255,0.3);
            color: white;
            border-radius: 10px;
            transition: all 0.3s ease;
        }
        
        .btn-copy:hover {
            background: rgba(255,255,255,0.3);
            color: white;
        }
        
        .qr-container {
            padding: 1rem;
            background: rgba(255,255,255,0.1);
            border-radius: 15px;
            backdrop-filter: blur(10px);
        }
        
        .qr-code-display {
            min-height: 150px;
            display: flex;
            align-items: center;
            justify-content: center;
            background: white;
            border-radius: 10px;
            padding: 10px;
        }
        
        .qr-code-display canvas {
            border-radius: 5px;
        }
        
        .qr-placeholder {
            color: #ccc;
            font-size: 0.9rem;
            text-align: center;
        }
    </style>
</head>
<body>
    <!-- 导航栏 -->
    <nav class="navbar navbar-expand-lg navbar-dark">
        <div class="container">
            <a class="navbar-brand" href="#">
                <i class="bi bi-diagram-3"></i> <?php echo SITE_NAME; ?>
            </a>
            <div class="navbar-nav ms-auto">
                <div class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle text-white" href="#" role="button" data-bs-toggle="dropdown">
                        <i class="bi bi-person-circle"></i> <?php echo htmlspecialchars($currentUser['username']); ?>
                    </a>
                    <ul class="dropdown-menu">
                        <li><a class="dropdown-item" href="profile.php"><i class="bi bi-person"></i> 个人资料</a></li>
                        <li><hr class="dropdown-divider"></li>
                        <li><a class="dropdown-item" href="logout.php"><i class="bi bi-box-arrow-right"></i> 退出登录</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </nav>

    <div class="container main-container">
        <!-- 统计卡片 -->
        <div class="row mb-4" data-aos="fade-up">
            <div class="col-md-3 mb-3">
                <div class="card stats-card">
                    <div class="card-body text-center">
                        <div class="stats-number"><?php echo $teamData[1]['size'] + $teamData[2]['size'] + $teamData[3]['size']; ?></div>
                        <div class="stats-label">团队总人数</div>
                    </div>
                </div>
            </div>
            <div class="col-md-3 mb-3">
                <div class="card stats-card">
                    <div class="card-body text-center">
                        <div class="stats-number"><?php echo CURRENCY_SYMBOL . formatAmount($referralEarnings); ?></div>
                        <div class="stats-label">推荐佣金</div>
                    </div>
                </div>
            </div>
            <div class="col-md-3 mb-3">
                <div class="card stats-card">
                    <div class="card-body text-center">
                        <div class="stats-number"><?php echo $referredUsers; ?></div>
                        <div class="stats-label">推荐用户数</div>
                    </div>
                </div>
            </div>
            <div class="col-md-3 mb-3">
                <div class="card stats-card">
                    <div class="card-body text-center">
                        <div class="stats-number"><?php echo CURRENCY_SYMBOL . formatAmount($withdrawalAmount); ?></div>
                        <div class="stats-label">已提现金额</div>
                    </div>
                </div>
            </div>
        </div>

        <!-- 团队级别卡片 -->
        <div class="row mb-4">
            <?php for ($level = 1; $level <= 3; $level++): ?>
            <div class="col-md-4 mb-3" data-aos="fade-up" data-aos-delay="<?php echo $level * 100; ?>">
                <div class="card team-card">
                    <div class="card-body">
                        <div class="level-badge level-<?php echo $level; ?>">
                            <i class="bi bi-people"></i> Level <?php echo $level; ?>
                        </div>
                        
                        <div class="team-stats">
                            <div class="team-stat-item">
                                <div class="team-stat-number"><?php echo $teamData[$level]['size']; ?></div>
                                <div class="team-stat-label">团队人数</div>
                            </div>
                            <div class="team-stat-item">
                                <div class="team-stat-number"><?php echo CURRENCY_SYMBOL . formatAmount($teamData[$level]['deposit']); ?></div>
                                <div class="team-stat-label">团队充值</div>
                            </div>
                        </div>
                        
                        <div class="text-center">
                            <a href="team_details.php?level=<?php echo $level; ?>" class="btn btn-details">
                                <i class="bi bi-eye"></i> 查看详情
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <?php endfor; ?>
        </div>

        <!-- 直接推荐列表 -->
        <div class="row mb-4" data-aos="fade-up">
            <div class="col-12">
                <div class="referral-table">
                    <div class="table-responsive">
                        <table class="table table-hover mb-0">
                            <thead>
                                <tr>
                                    <th><i class="bi bi-person"></i> 用户</th>
                                    <th><i class="bi bi-envelope"></i> 邮箱</th>
                                    <th><i class="bi bi-wallet2"></i> 充值钱包</th>
                                    <th><i class="bi bi-piggy-bank"></i> 收益钱包</th>
                                    <th><i class="bi bi-calendar"></i> 注册时间</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if (empty($directReferrals)): ?>
                                <tr>
                                    <td colspan="5" class="text-center py-4">
                                        <i class="bi bi-inbox" style="font-size: 2rem; color: #ccc;"></i>
                                        <div class="mt-2 text-muted">暂无直接推荐用户</div>
                                    </td>
                                </tr>
                                <?php else: ?>
                                    <?php foreach ($directReferrals as $referral): ?>
                                    <tr>
                                        <td>
                                            <div class="d-flex align-items-center">
                                                <div class="user-avatar me-3">
                                                    <?php echo strtoupper(substr($referral['username'], 0, 1)); ?>
                                                </div>
                                                <span class="fw-medium"><?php echo htmlspecialchars($referral['username']); ?></span>
                                            </div>
                                        </td>
                                        <td><?php echo htmlspecialchars($referral['email']); ?></td>
                                        <td class="<?php echo $referral['deposit_wallet'] > 0 ? 'amount-positive' : 'amount-zero'; ?>">
                                            <?php echo CURRENCY_SYMBOL . formatAmount($referral['deposit_wallet']); ?>
                                        </td>
                                        <td class="<?php echo $referral['interest_wallet'] > 0 ? 'amount-positive' : 'amount-zero'; ?>">
                                            <?php echo CURRENCY_SYMBOL . formatAmount($referral['interest_wallet']); ?>
                                        </td>
                                        <td><?php echo date('Y-m-d H:i', strtotime($referral['created_at'])); ?></td>
                                    </tr>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

        <!-- 邀请链接部分 -->
        <div class="invite-section" data-aos="fade-up">
            <div class="row align-items-center">
                <div class="col-md-8">
                    <h4><i class="bi bi-share"></i> 邀请好友加入</h4>
                    <p class="mb-3">分享您的专属推荐码，邀请好友注册并获得佣金奖励</p>
                    
                    <div class="row">
                        <div class="col-md-6 mb-2">
                            <label class="form-label">推荐码:</label>
                            <div class="input-group">
                                <input type="text" class="form-control invite-code" 
                                       value="<?php echo $currentUser['refCode']; ?>" 
                                       id="referralCode" readonly>
                                <button class="btn btn-copy" type="button" onclick="copyToClipboard('referralCode')">
                                    <i class="bi bi-copy"></i> 复制
                                </button>
                            </div>
                        </div>
                        <div class="col-md-6 mb-2">
                            <label class="form-label">邀请链接:</label>
                            <div class="input-group">
                                <input type="text" class="form-control invite-code" 
                                       value="https://127.0.0.1.top?pages/login/register=<?php echo $currentUser['refCode']; ?>" 
                                       id="referralLink" readonly>
                                <button class="btn btn-copy" type="button" onclick="copyToClipboard('referralLink')">
                                    <i class="bi bi-copy"></i> 复制
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 text-center">
                    <div class="qr-container">
                        <div id="qrcode" class="qr-code-display mb-2"></div>
                        <button class="btn btn-primary btn-sm" onclick="generateQRCode()">
                            <i class="bi bi-qr-code"></i> 生成二维码
                        </button>
                        <div class="mt-2 small text-muted">扫码邀请好友注册</div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/aos@2.3.4/dist/aos.js"></script>
    <script>
        // 初始化AOS动画
        AOS.init({
            duration: 800,
            easing: 'ease-in-out',
            once: true
        });

        // 复制到剪贴板功能
        function copyToClipboard(elementId) {
            const element = document.getElementById(elementId);
            element.select();
            element.setSelectionRange(0, 99999);
            
            try {
                document.execCommand('copy');
                showToast('复制成功！', 'success');
            } catch (err) {
                showToast('复制失败，请手动复制', 'error');
            }
        }

        // 显示提示消息
        function showToast(message, type = 'info') {
            const toast = document.createElement('div');
            let alertClass, iconClass;
            
            switch(type) {
                case 'success':
                    alertClass = 'alert-success';
                    iconClass = 'check-circle';
                    break;
                case 'error':
                    alertClass = 'alert-danger';
                    iconClass = 'exclamation-triangle';
                    break;
                case 'info':
                default:
                    alertClass = 'alert-info';
                    iconClass = 'info-circle';
                    break;
            }
            
            toast.className = `alert ${alertClass} position-fixed`;
            toast.style.cssText = 'top: 20px; right: 20px; z-index: 9999; min-width: 300px;';
            toast.innerHTML = `
                <i class="bi bi-${iconClass}"></i>
                ${message}
                <button type="button" class="btn-close" onclick="this.parentElement.remove()"></button>
            `;
            
            document.body.appendChild(toast);
            
            setTimeout(() => {
                if (toast.parentElement) {
                    toast.remove();
                }
            }, 3000);
        }

        // 统计数字动画
        function animateNumbers() {
            // 仅对顶部统计卡片（.stats-number）做动画，
            // 团队级别卡片（.team-stat-number）保持静态，避免金额被错误格式化
            const numbers = document.querySelectorAll('.stats-number');
            numbers.forEach(number => {
                const originalText = number.textContent.trim();
                const hasCurrency = /[$€£¥]/.test(originalText);
                const numericStr = originalText.replace(/[^0-9.\-]/g, ''); // 保留小数点与负号
                const finalValue = parseFloat(numericStr);

                if (!isNaN(finalValue) && finalValue > 0) {
                    let currentValue = 0;
                    const steps = 50;
                    const increment = finalValue / steps;
                    const decimals = (hasCurrency || /\./.test(numericStr)) ? 2 : 0;
                    const currencyPrefix = hasCurrency ? (originalText.match(/^[^0-9\-]+/)?.[0] || '') : '';

                    const timer = setInterval(() => {
                        currentValue += increment;
                        if (currentValue >= finalValue) {
                            currentValue = finalValue;
                            clearInterval(timer);
                        }
                        const formatted = Number(currentValue).toLocaleString(undefined, {
                            minimumFractionDigits: decimals,
                            maximumFractionDigits: decimals
                        });
                        number.textContent = currencyPrefix + formatted;
                    }, 20);
                }
            });
        }

        // 生成二维码功能
        function generateQRCode() {
            const referralLink = document.getElementById('referralLink').value;
            const qrContainer = document.getElementById('qrcode');
            
            // 清空之前的内容
            qrContainer.innerHTML = '';
            
            // 显示加载提示
            qrContainer.innerHTML = '<div class="qr-placeholder">正在生成二维码...</div>';
            
            try {
                // 使用Google Charts API生成二维码
                const qrSize = 150;
                const qrUrl = `https://api.qrserver.com/v1/create-qr-code/?size=${qrSize}x${qrSize}&data=${encodeURIComponent(referralLink)}`;
                
                // 创建图片元素
                const img = document.createElement('img');
                img.src = qrUrl;
                img.alt = '邀请二维码';
                img.style.maxWidth = '100%';
                img.style.height = 'auto';
                img.style.borderRadius = '5px';
                
                // 监听图片加载
                img.onload = function() {
                    qrContainer.innerHTML = '';
                    qrContainer.appendChild(img);
                    showToast('二维码生成成功！', 'success');
                };
                
                img.onerror = function() {
                    // 如果第一个API失败，尝试备用API
                    console.log('第一个二维码API失败，尝试备用方案...');
                    tryBackupQRAPI(referralLink, qrContainer);
                };
                
            } catch (error) {
                console.error('QR码生成失败:', error);
                qrContainer.innerHTML = '<div class="qr-placeholder">二维码生成失败</div>';
                showToast('二维码生成失败', 'error');
            }
        }
        
        // 备用二维码生成方案
        function tryBackupQRAPI(referralLink, qrContainer) {
            qrContainer.innerHTML = '<div class="qr-placeholder">尝试备用方案...</div>';
            
            // 使用chart.googleapis.com API
            const qrSize = 150;
            const qrUrl = `https://chart.googleapis.com/chart?chs=${qrSize}x${qrSize}&cht=qr&chl=${encodeURIComponent(referralLink)}`;
            
            const img = document.createElement('img');
            img.src = qrUrl;
            img.alt = '邀请二维码';
            img.style.maxWidth = '100%';
            img.style.height = 'auto';
            img.style.borderRadius = '5px';
            
            img.onload = function() {
                qrContainer.innerHTML = '';
                qrContainer.appendChild(img);
                showToast('二维码生成成功！', 'success');
            };
            
            img.onerror = function() {
                // 如果备用API也失败，显示文本二维码
                generateTextQRCode(referralLink, qrContainer);
            };
        }
        
        // 文本二维码生成（最后备用方案）
        function generateTextQRCode(referralLink, qrContainer) {
            qrContainer.innerHTML = `
                <div class="text-center p-3">
                    <div class="mb-2">
                        <i class="bi bi-qr-code" style="font-size: 3rem; color: #6c757d;"></i>
                    </div>
                    <div class="small text-muted mb-2">二维码服务暂时不可用</div>
                    <div class="small">
                        <strong>邀请链接:</strong><br>
                        <a href="${referralLink}" target="_blank" class="text-primary" style="word-break: break-all;">
                            ${referralLink}
                        </a>
                    </div>
                </div>
            `;
            showToast('二维码服务不可用，已显示邀请链接', 'info');
        }
        
        // 页面加载完成后执行动画和初始化二维码占位符
        document.addEventListener('DOMContentLoaded', function() {
            setTimeout(animateNumbers, 500);
            
            // 初始化二维码占位符
            const qrContainer = document.getElementById('qrcode');
            qrContainer.innerHTML = '<div class="qr-placeholder">点击按钮生成邀请二维码</div>';
        });
    </script>
</body>
</html>