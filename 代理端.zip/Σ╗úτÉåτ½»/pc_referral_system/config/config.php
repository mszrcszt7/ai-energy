<?php
/**
 * 系统配置文件
 */

// 开启Session
session_start();

// 错误报告设置
error_reporting(E_ALL);
ini_set('display_errors', 1);

// 时区设置
date_default_timezone_set('Asia/Shanghai');

// 网站基本配置
define('SITE_NAME', 'AI新能源管理系统');
define('SITE_URL', 'http://128.241.238.157:8099');
define('BASE_PATH', dirname(__DIR__));

// 数据库配置
define('DB_HOST', 'localhost');
define('DB_NAME', '128_241_238_157');
define('DB_USER', 'root');
define('DB_PASS', '7e7ed354116de4c4');

// 安全配置
define('SESSION_TIMEOUT', 3600); // 1小时
define('CSRF_TOKEN_NAME', '_token');

// 货币符号
define('CURRENCY_SYMBOL', '$');

// 推荐级别配置
define('MAX_REFERRAL_LEVEL', 3);

// 自动加载类文件
spl_autoload_register(function ($className) {
    $paths = [
        BASE_PATH . '/classes/',
        BASE_PATH . '/config/',
        BASE_PATH . '/includes/'
    ];
    
    foreach ($paths as $path) {
        $file = $path . $className . '.php';
        if (file_exists($file)) {
            require_once $file;
            return;
        }
    }
});

// 引入数据库连接
require_once BASE_PATH . '/config/database.php';

// 工具函数
function formatAmount($amount, $decimals = 2) {
    return number_format($amount, $decimals, '.', ',');
}

function generateToken() {
    return bin2hex(random_bytes(32));
}

function isLoggedIn() {
    return isset($_SESSION['user_id']) && !empty($_SESSION['user_id']);
}

function requireLogin() {
    if (!isLoggedIn()) {
        header('Location: login.php');
        exit;
    }
}

function getCurrentUser() {
    if (!isLoggedIn()) {
        return null;
    }
    
    $db = new Database();
    return $db->fetch("SELECT * FROM users WHERE id = ?", [$_SESSION['user_id']]);
}

function redirect($url) {
    header("Location: $url");
    exit;
}

function showError($message) {
    $_SESSION['error'] = $message;
}

function showSuccess($message) {
    $_SESSION['success'] = $message;
}

function getFlashMessage($type) {
    if (isset($_SESSION[$type])) {
        $message = $_SESSION[$type];
        unset($_SESSION[$type]);
        return $message;
    }
    return null;
}