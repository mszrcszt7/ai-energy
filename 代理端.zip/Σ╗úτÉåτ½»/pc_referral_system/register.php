<?php
require_once 'config/config.php';

// 如果已经登录，跳转到推荐页面
if (isLoggedIn()) {
    redirect('referrals.php');
}

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = trim($_POST['username'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $password = trim($_POST['password'] ?? '');
    $confirm_password = trim($_POST['confirm_password'] ?? '');
    $referrer_code = trim($_POST['referrer_code'] ?? '');

    // 验证输入
    if (empty($username) || empty($email) || empty($password)) {
        $error = '请填写所有必填字段';
    } elseif ($password !== $confirm_password) {
        $error = '两次输入的密码不一致';
    } elseif (strlen($password) < 6) {
        $error = '密码长度至少6位';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = '请输入有效的邮箱地址';
    } else {
        $user = new User();
        if ($user->register($username, $email, $password, $referrer_code)) {
            showSuccess('注册成功，请登录');
            redirect('login.php');
        } else {
            $error = '注册失败，用户名或邮箱已存在';
        }
    }
}

// 获取闪存消息
$error = $error ?: getFlashMessage('error');
$success = getFlashMessage('success');
?>

<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>注册 - <?php echo SITE_NAME; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.7.2/font/bootstrap-icons.css" rel="stylesheet">
    <style>
        body {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            padding: 2rem 0;
        }
        .register-container {
            background: rgba(255, 255, 255, 0.95);
            border-radius: 20px;
            box-shadow: 0 15px 35px rgba(0, 0, 0, 0.1);
            backdrop-filter: blur(10px);
        }
        .register-header {
            background: linear-gradient(135deg, #fcd535 0%, #f0b90b 100%);
            color: white;
            border-radius: 20px 20px 0 0;
            padding: 2rem;
            text-align: center;
        }
        .form-control:focus {
            border-color: #fcd535;
            box-shadow: 0 0 0 0.2rem rgba(252, 213, 53, 0.25);
        }
        .btn-register {
            background: linear-gradient(135deg, #fcd535 0%, #f0b90b 100%);
            border: none;
            color: white;
            font-weight: 600;
            padding: 12px 0;
            border-radius: 10px;
            transition: all 0.3s ease;
        }
        .btn-register:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(252, 213, 53, 0.4);
            color: white;
        }
        .input-group-text {
            background: transparent;
            border-right: none;
        }
        .form-control {
            border-left: none;
        }
        .login-link {
            color: #667eea;
            text-decoration: none;
            font-weight: 500;
        }
        .login-link:hover {
            color: #764ba2;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8 col-lg-6">
                <div class="register-container">
                    <div class="register-header">
                        <h2><i class="bi bi-person-plus"></i> 用户注册</h2>
                            <p class="mb-0">加入AI新能源管理系统</p>
                    </div>
                    
                    <div class="p-4">
                        <?php if ($error): ?>
                            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                                <i class="bi bi-exclamation-triangle"></i> <?php echo htmlspecialchars($error); ?>
                                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                            </div>
                        <?php endif; ?>

                        <?php if ($success): ?>
                            <div class="alert alert-success alert-dismissible fade show" role="alert">
                                <i class="bi bi-check-circle"></i> <?php echo htmlspecialchars($success); ?>
                                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                            </div>
                        <?php endif; ?>

                        <form method="POST" action="">
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label for="username" class="form-label">用户名 <span class="text-danger">*</span></label>
                                    <div class="input-group">
                                        <span class="input-group-text">
                                            <i class="bi bi-person"></i>
                                        </span>
                                        <input type="text" 
                                               class="form-control" 
                                               id="username" 
                                               name="username" 
                                               placeholder="请输入用户名"
                                               value="<?php echo htmlspecialchars($_POST['username'] ?? ''); ?>"
                                               required>
                                    </div>
                                </div>

                                <div class="col-md-6 mb-3">
                                    <label for="email" class="form-label">邮箱地址 <span class="text-danger">*</span></label>
                                    <div class="input-group">
                                        <span class="input-group-text">
                                            <i class="bi bi-envelope"></i>
                                        </span>
                                        <input type="email" 
                                               class="form-control" 
                                               id="email" 
                                               name="email" 
                                               placeholder="请输入邮箱地址"
                                               value="<?php echo htmlspecialchars($_POST['email'] ?? ''); ?>"
                                               required>
                                    </div>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label for="password" class="form-label">密码 <span class="text-danger">*</span></label>
                                    <div class="input-group">
                                        <span class="input-group-text">
                                            <i class="bi bi-lock"></i>
                                        </span>
                                        <input type="password" 
                                               class="form-control" 
                                               id="password" 
                                               name="password" 
                                               placeholder="请输入密码（至少6位）"
                                               required>
                                    </div>
                                </div>

                                <div class="col-md-6 mb-3">
                                    <label for="confirm_password" class="form-label">确认密码 <span class="text-danger">*</span></label>
                                    <div class="input-group">
                                        <span class="input-group-text">
                                            <i class="bi bi-lock-fill"></i>
                                        </span>
                                        <input type="password" 
                                               class="form-control" 
                                               id="confirm_password" 
                                               name="confirm_password" 
                                               placeholder="请再次输入密码"
                                               required>
                                    </div>
                                </div>
                            </div>

                            <div class="mb-4">
                                <label for="referrer_code" class="form-label">推荐人代码 <small class="text-muted">(可选)</small></label>
                                <div class="input-group">
                                    <span class="input-group-text">
                                        <i class="bi bi-share"></i>
                                    </span>
                                    <input type="text" 
                                           class="form-control" 
                                           id="referrer_code" 
                                           name="referrer_code" 
                                           placeholder="请输入推荐人代码"
                                           value="<?php echo htmlspecialchars($_POST['referrer_code'] ?? $_GET['ref'] ?? ''); ?>">
                                </div>
                                <small class="form-text text-muted">如果您有推荐人，请输入推荐人代码</small>
                            </div>

                            <button type="submit" class="btn btn-register w-100">
                                <i class="bi bi-person-plus"></i> 注册账户
                            </button>
                        </form>

                        <div class="text-center mt-4">
                            <p class="mb-0">已有账户？ 
                                <a href="login.php" class="login-link">立即登录</a>
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>