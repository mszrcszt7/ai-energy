<?php
/**
 * 数据库连接测试文件
 */
error_reporting(E_ALL);
ini_set('display_errors', 1);

echo "<h2>数据库连接测试</h2>";

try {
    // 测试数据库连接
    $host = 'localhost';
    $dbname = '128_241_238_157';
    $username = 'root';
    $password = '7e7ed354116de4c4';
    
    $dsn = "mysql:host={$host};dbname={$dbname};charset=utf8mb4";
    $pdo = new PDO($dsn, $username, $password, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    ]);
    
    echo "<p style='color: green;'>✅ 数据库连接成功！</p>";
    
    // 测试用户表
    $stmt = $pdo->query("SELECT COUNT(*) as count FROM users");
    $result = $stmt->fetch();
    echo "<p>📊 用户表记录数: " . $result['count'] . "</p>";
    
    // 测试获取一个用户
    $stmt = $pdo->query("SELECT id, username, email FROM users LIMIT 1");
    $user = $stmt->fetch();
    if ($user) {
        echo "<p>👤 示例用户: ID={$user['id']}, 用户名={$user['username']}, 邮箱={$user['email']}</p>";
    }
    
    // 测试交易表
    $stmt = $pdo->query("SELECT COUNT(*) as count FROM transactions");
    $result = $stmt->fetch();
    echo "<p>💰 交易记录数: " . $result['count'] . "</p>";
    
} catch (PDOException $e) {
    echo "<p style='color: red;'>❌ 数据库连接失败: " . $e->getMessage() . "</p>";
}

echo "<hr>";
echo "<h3>PHP环境信息</h3>";
echo "<p>PHP版本: " . phpversion() . "</p>";
echo "<p>PDO支持: " . (extension_loaded('pdo') ? '✅ 是' : '❌ 否') . "</p>";
echo "<p>PDO MySQL支持: " . (extension_loaded('pdo_mysql') ? '✅ 是' : '❌ 否') . "</p>";
echo "<p>Session支持: " . (extension_loaded('session') ? '✅ 是' : '❌ 否') . "</p>";

echo "<hr>";
echo "<h3>文件路径信息</h3>";
echo "<p>当前文件路径: " . __FILE__ . "</p>";
echo "<p>当前目录: " . __DIR__ . "</p>";
echo "<p>网站根目录: " . $_SERVER['DOCUMENT_ROOT'] . "</p>";

echo "<hr>";
echo "<p><a href='index.php'>返回首页</a> | <a href='login.php'>登录页面</a></p>";
?>