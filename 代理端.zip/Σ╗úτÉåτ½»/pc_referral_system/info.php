<?php
// PHP环境检测文件
phpinfo();
?>