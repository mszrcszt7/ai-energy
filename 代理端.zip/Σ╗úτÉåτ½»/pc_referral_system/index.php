<?php
require_once 'config/config.php';

// 如果已经登录，跳转到推荐页面
if (isLoggedIn()) {
    redirect('referrals.php');
} else {
    redirect('login.php');
}
?>