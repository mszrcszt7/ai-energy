<?php
require_once 'config/config.php';

$user = new User();
$user->logout();

showSuccess('您已成功退出登录');
redirect('login.php');
?>