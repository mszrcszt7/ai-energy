<?php
require_once 'config/config.php';

// 检查登录状态
requireLogin();

$level = (int)($_GET['level'] ?? 1);
if ($level < 1 || $level > 3) {
    $level = 1;
}

$user = new User();
$currentUser = getCurrentUser();

// 获取指定级别的推荐用户
$referrals = $user->getReferralsByLevel($currentUser['id'], $level);
$teamSize = $user->getTeamSize($currentUser['id'], $level);
$teamDeposit = $user->getTeamDeposit($currentUser['id'], $level);

$levelNames = [
    1 => '一级团队',
    2 => '二级团队', 
    3 => '三级团队'
];
?>

<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $levelNames[$level]; ?> - <?php echo SITE_NAME; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.7.2/font/bootstrap-icons.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/aos@2.3.4/dist/aos.css" rel="stylesheet">
    <style>
        body {
            background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        
        .navbar {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            box-shadow: 0 2px 20px rgba(0,0,0,0.1);
        }
        
        .navbar-brand {
            font-weight: 700;
            font-size: 1.5rem;
        }
        
        .main-container {
            margin-top: 2rem;
            margin-bottom: 2rem;
        }
        
        .page-header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border-radius: 20px;
            padding: 2rem;
            margin-bottom: 2rem;
        }
        
        .level-badge {
            display: inline-block;
            padding: 0.5rem 1rem;
            border-radius: 25px;
            font-weight: 600;
            font-size: 0.9rem;
            margin-bottom: 1rem;
        }
        
        .level-1 { background: linear-gradient(135deg, #ff9a9e 0%, #fecfef 100%); color: #fff; }
        .level-2 { background: linear-gradient(135deg, #a18cd1 0%, #fbc2eb 100%); color: #fff; }
        .level-3 { background: linear-gradient(135deg, #fad0c4 0%, #ffd1ff 100%); color: #fff; }
        
        .stats-row {
            background: rgba(255,255,255,0.2);
            border-radius: 15px;
            padding: 1.5rem;
            margin-top: 1rem;
        }
        
        .stat-item {
            text-align: center;
        }
        
        .stat-number {
            font-size: 2rem;
            font-weight: 700;
            margin-bottom: 0.5rem;
        }
        
        .stat-label {
            font-size: 0.9rem;
            opacity: 0.9;
        }
        
        .team-table {
            background: white;
            border-radius: 15px;
            overflow: hidden;
            box-shadow: 0 5px 25px rgba(0,0,0,0.08);
        }
        
        .table th {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border: none;
            font-weight: 600;
        }
        
        .table td {
            border-color: #f8f9fa;
            vertical-align: middle;
        }
        
        .user-avatar {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background: linear-gradient(135deg, #fcd535 0%, #f0b90b 100%);
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: 600;
        }
        
        .amount-positive {
            color: #28a745;
            font-weight: 600;
        }
        
        .amount-zero {
            color: #6c757d;
        }
        
        .btn-back {
            background: rgba(255,255,255,0.2);
            border: 2px solid rgba(255,255,255,0.3);
            color: white;
            border-radius: 10px;
            padding: 0.5rem 1.5rem;
            text-decoration: none;
            transition: all 0.3s ease;
        }
        
        .btn-back:hover {
            background: rgba(255,255,255,0.3);
            color: white;
            text-decoration: none;
        }
        
        .pagination .page-link {
            color: #667eea;
            border: none;
            margin: 0 2px;
            border-radius: 8px;
        }
        
        .pagination .page-item.active .page-link {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            border-color: transparent;
        }
    </style>
</head>
<body>
    <!-- 导航栏 -->
    <nav class="navbar navbar-expand-lg navbar-dark">
        <div class="container">
            <a class="navbar-brand" href="referrals.php">
                <i class="bi bi-diagram-3"></i> <?php echo SITE_NAME; ?>
            </a>
            <div class="navbar-nav ms-auto">
                <div class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle text-white" href="#" role="button" data-bs-toggle="dropdown">
                        <i class="bi bi-person-circle"></i> <?php echo htmlspecialchars($currentUser['username']); ?>
                    </a>
                    <ul class="dropdown-menu">
                        <li><a class="dropdown-item" href="profile.php"><i class="bi bi-person"></i> 个人资料</a></li>
                        <li><hr class="dropdown-divider"></li>
                        <li><a class="dropdown-item" href="logout.php"><i class="bi bi-box-arrow-right"></i> 退出登录</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </nav>

    <div class="container main-container">
        <!-- 页面头部 -->
        <div class="page-header" data-aos="fade-down">
            <div class="d-flex justify-content-between align-items-center">
                <div>
                    <div class="level-badge level-<?php echo $level; ?>">
                        <i class="bi bi-people"></i> Level <?php echo $level; ?>
                    </div>
                    <h2 class="mb-0"><?php echo $levelNames[$level]; ?>详情</h2>
                    <p class="mb-0">查看您的<?php echo $levelNames[$level]; ?>成员信息</p>
                </div>
                <div>
                    <a href="referrals.php" class="btn-back">
                        <i class="bi bi-arrow-left"></i> 返回团队总览
                    </a>
                </div>
            </div>
            
            <!-- 统计数据 -->
            <div class="stats-row">
                <div class="row">
                    <div class="col-md-6">
                        <div class="stat-item">
                            <div class="stat-number"><?php echo $teamSize; ?></div>
                            <div class="stat-label">团队人数</div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="stat-item">
                            <div class="stat-number"><?php echo CURRENCY_SYMBOL . formatAmount($teamDeposit); ?></div>
                            <div class="stat-label">团队充值总额</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- 团队成员列表 -->
        <div class="row" data-aos="fade-up">
            <div class="col-12">
                <div class="team-table">
                    <div class="table-responsive">
                        <table class="table table-hover mb-0">
                            <thead>
                                <tr>
                                    <th><i class="bi bi-hash"></i> #</th>
                                    <th><i class="bi bi-person"></i> 用户名</th>
                                    <th><i class="bi bi-envelope"></i> 邮箱</th>
                                    <th><i class="bi bi-wallet2"></i> 充值钱包</th>
                                    <th><i class="bi bi-piggy-bank"></i> 收益钱包</th>
                                    <th><i class="bi bi-calendar"></i> 注册时间</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if (empty($referrals)): ?>
                                <tr>
                                    <td colspan="6" class="text-center py-5">
                                        <i class="bi bi-inbox" style="font-size: 3rem; color: #ccc;"></i>
                                        <div class="mt-3 text-muted h5">暂无<?php echo $levelNames[$level]; ?>成员</div>
                                        <p class="text-muted">邀请好友注册，建立您的推荐团队</p>
                                    </td>
                                </tr>
                                <?php else: ?>
                                    <?php foreach ($referrals as $index => $referral): ?>
                                    <tr data-aos="fade-in" data-aos-delay="<?php echo $index * 50; ?>">
                                        <td><?php echo $index + 1; ?></td>
                                        <td>
                                            <div class="d-flex align-items-center">
                                                <div class="user-avatar me-3">
                                                    <?php echo strtoupper(substr($referral['username'], 0, 1)); ?>
                                                </div>
                                                <span class="fw-medium"><?php echo htmlspecialchars($referral['username']); ?></span>
                                            </div>
                                        </td>
                                        <td><?php echo htmlspecialchars($referral['email']); ?></td>
                                        <td class="<?php echo $referral['deposit_wallet'] > 0 ? 'amount-positive' : 'amount-zero'; ?>">
                                            <i class="bi bi-wallet2 me-1"></i>
                                            <?php echo CURRENCY_SYMBOL . formatAmount($referral['deposit_wallet']); ?>
                                        </td>
                                        <td class="<?php echo $referral['interest_wallet'] > 0 ? 'amount-positive' : 'amount-zero'; ?>">
                                            <i class="bi bi-piggy-bank me-1"></i>
                                            <?php echo CURRENCY_SYMBOL . formatAmount($referral['interest_wallet']); ?>
                                        </td>
                                        <td>
                                            <small class="text-muted">
                                                <?php echo date('Y-m-d', strtotime($referral['created_at'])); ?>
                                            </small>
                                            <br>
                                            <small class="text-muted">
                                                <?php echo date('H:i:s', strtotime($referral['created_at'])); ?>
                                            </small>
                                        </td>
                                    </tr>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

        <!-- 级别导航 -->
        <div class="row mt-4" data-aos="fade-up">
            <div class="col-12">
                <div class="d-flex justify-content-center">
                    <div class="btn-group" role="group">
                        <?php for ($i = 1; $i <= 3; $i++): ?>
                        <a href="team_details.php?level=<?php echo $i; ?>" 
                           class="btn <?php echo $i == $level ? 'btn-primary' : 'btn-outline-primary'; ?>">
                            Level <?php echo $i; ?>
                            <span class="badge bg-light text-dark ms-1">
                                <?php echo $user->getTeamSize($currentUser['id'], $i); ?>
                            </span>
                        </a>
                        <?php endfor; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/aos@2.3.4/dist/aos.js"></script>
    <script>
        // 初始化AOS动画
        AOS.init({
            duration: 600,
            easing: 'ease-in-out',
            once: true
        });

        // 统计数字动画（保留货币与小数，不改变金额数值）
        function animateNumbers() {
            const numbers = document.querySelectorAll('.stat-number');
            numbers.forEach(number => {
                const originalText = number.textContent.trim();
                const hasCurrency = /[$€£¥]/.test(originalText);
                const numericStr = originalText.replace(/[^0-9.\-]/g, '');
                const finalValue = parseFloat(numericStr);

                if (!isNaN(finalValue) && finalValue > 0) {
                    let currentValue = 0;
                    const steps = 30;
                    const increment = finalValue / steps;
                    const decimals = (hasCurrency || /\./.test(numericStr)) ? 2 : 0;
                    const currencyPrefix = hasCurrency ? (originalText.match(/^[^0-9\-]+/)?.[0] || '') : '';

                    const timer = setInterval(() => {
                        currentValue += increment;
                        if (currentValue >= finalValue) {
                            currentValue = finalValue;
                            clearInterval(timer);
                        }

                        const formatted = Number(currentValue).toLocaleString(undefined, {
                            minimumFractionDigits: decimals,
                            maximumFractionDigits: decimals
                        });
                        number.textContent = currencyPrefix + formatted;
                    }, 30);
                }
            });
        }

        // 页面加载完成后执行动画
        document.addEventListener('DOMContentLoaded', function() {
            setTimeout(animateNumbers, 300);
        });
    </script>
</body>
</html>